#!/usr/bin/env python3
"""Genera ModItems.java, ModBlocks.java, modelli, blockstate, texture segnaposto,
lingua IT/EN, ricette, loot table e tag a partire dalle tabelle qui sotto."""
import hashlib
import json
import os
import struct
import zlib

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MOD = "medievalcraft"
JAVA = f"{ROOT}/src/main/java/com/medievalcraft"
ASSETS = f"{ROOT}/src/main/resources/assets/{MOD}"
DATA = f"{ROOT}/src/main/resources/data/{MOD}"


# ---------------------------------------------------------------- utilità
def wf(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def wj(path, obj):
    wf(path, json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def png(path, width, height, pix):
    raw = b""
    for y in range(height):
        raw += b"\x00" + b"".join(bytes(pix(x, y)) for x in range(width))

    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    blob = (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw))
            + chunk(b"IEND", b""))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(blob)


def noise(name, x, y, amp=14):
    h = hashlib.md5(f"{name}{x},{y}".encode()).digest()[0]
    return (h % (amp * 2 + 1)) - amp


def clamp(v):
    return max(0, min(255, v))


def shade(color, d):
    return tuple(clamp(c + d) for c in color)


# ---------------------------------------------------------------- tabelle
# --- Cibi: id, it, en, nutrizione, saturazione, tipo, colore
FOODS = [
    ("pane_nero", "Pane nero", "Black Bread", 5, 0.6, "plain", (92, 64, 40)),
    ("pane_bianco", "Pane bianco dei nobili", "Noble White Bread", 6, 0.7, "plain", (232, 205, 150)),
    ("zuppa_di_porri", "Zuppa di porri", "Leek Soup", 6, 0.6, "bowl", (150, 190, 110)),
    ("stufato_di_cinghiale", "Stufato di cinghiale", "Boar Stew", 10, 0.8, "bowl", (130, 80, 50)),
    ("cinghiale_arrosto", "Cinghiale arrosto", "Roast Boar", 9, 0.9, "plain", (150, 85, 45)),
    ("salsiccia", "Salsiccia", "Sausage", 6, 0.6, "plain", (170, 70, 60)),
    ("formaggio_stagionato", "Formaggio stagionato", "Aged Cheese", 4, 0.5, "plain", (235, 190, 70)),
    ("torta_di_carne", "Torta di carne", "Meat Pie", 8, 0.7, "plain", (200, 140, 70)),
    ("torta_di_mele", "Torta di mele", "Apple Tart", 7, 0.5, "plain", (215, 160, 80)),
    ("pollo_arrosto", "Pollo arrosto", "Roast Chicken", 8, 0.8, "plain", (190, 120, 50)),
    ("pesce_affumicato", "Pesce affumicato", "Smoked Fish", 6, 0.7, "plain", (160, 120, 80)),
    ("aringa_salata", "Aringa salata", "Salted Herring", 4, 0.4, "plain", (140, 150, 160)),
    ("pottage", "Pottage (zuppa di cereali)", "Pottage", 7, 0.6, "bowl", (190, 160, 100)),
]

# --- Bevande: id, it, en, java builder del cibo, colore
DRINKS = [
    ("idromele", "Idromele", "Mead",
     "new FoodProperties.Builder().nutrition(2).saturationMod(0.3F).alwaysEat()"
     ".effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 0), 1.0F).build()",
     (230, 170, 40)),
    ("birra_medievale", "Birra medievale", "Medieval Ale",
     "new FoodProperties.Builder().nutrition(3).saturationMod(0.3F).alwaysEat()"
     ".effect(() -> new MobEffectInstance(MobEffects.CONFUSION, 120, 0), 0.25F).build()",
     (200, 140, 40)),
    ("ipocrasso", "Ipocrasso (vino speziato)", "Hippocras (Spiced Wine)",
     "new FoodProperties.Builder().nutrition(2).saturationMod(0.3F).alwaysEat()"
     ".effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 600, 0), 1.0F)"
     ".effect(() -> new MobEffectInstance(MobEffects.CONFUSION, 100, 0), 0.3F).build()",
     (140, 30, 60)),
]

# --- Abiti: id, it, en, materiale, slot, colore
CLOTHES = [
    ("contadino_cappuccio", "Cappuccio da contadino", "Peasant Hood", "CONTADINO", "HELMET", (200, 190, 160)),
    ("contadino_tunica", "Tunica da contadino", "Peasant Tunic", "CONTADINO", "CHESTPLATE", (200, 190, 160)),
    ("contadino_calzoni", "Calzoni da contadino", "Peasant Breeches", "CONTADINO", "LEGGINGS", (150, 130, 100)),
    ("contadino_scarpe", "Scarpe di cuoio", "Leather Shoes", "CONTADINO", "BOOTS", (120, 80, 50)),
    ("nobile_cappello", "Cappello di velluto", "Velvet Hat", "NOBILE", "HELMET", (110, 40, 130)),
    ("nobile_farsetto", "Farsetto nobiliare", "Noble Doublet", "NOBILE", "CHESTPLATE", (110, 40, 130)),
    ("nobile_calze", "Calze nobiliari", "Noble Hose", "NOBILE", "LEGGINGS", (170, 140, 40)),
    ("nobile_poulaines", "Poulaines (scarpe a punta)", "Poulaines", "NOBILE", "BOOTS", (90, 30, 40)),
    ("monaco_cappuccio", "Cappuccio da monaco", "Monk's Cowl", "MONACO", "HELMET", (110, 80, 50)),
    ("monaco_tonaca", "Tonaca da monaco", "Monk's Habit", "MONACO", "CHESTPLATE", (110, 80, 50)),
    ("monaco_brache", "Brache da monaco", "Monk's Breeches", "MONACO", "LEGGINGS", (95, 70, 45)),
    ("monaco_sandali", "Sandali da monaco", "Monk's Sandals", "MONACO", "BOOTS", (140, 100, 60)),
    ("boia_cappuccio", "Cappuccio del boia", "Executioner's Hood", "BOIA", "HELMET", (30, 30, 34)),
    ("boia_giubba", "Giubba del boia", "Executioner's Jerkin", "BOIA", "CHESTPLATE", (40, 38, 44)),
    ("boia_pantaloni", "Pantaloni del boia", "Executioner's Trousers", "BOIA", "LEGGINGS", (35, 33, 38)),
    ("boia_stivali", "Stivali del boia", "Executioner's Boots", "BOIA", "BOOTS", (25, 25, 28)),
    ("maschera_della_vergogna", "Maschera della vergogna", "Mask of Shame", "TORTURA", "HELMET", (150, 150, 155)),
    ("stivale_spagnolo", "Stivale spagnolo", "Spanish Boot", "TORTURA", "BOOTS", (130, 130, 135)),
]

# --- Armi: id, it, en, java, colore, tipo texture
WEAPONS = [
    ("frusta", "Frusta", "Whip", "new WhipItem(1, -1.0F, 4, p())", (120, 80, 45), "tool"),
    ("gatto_a_nove_code", "Gatto a nove code", "Cat-o'-Nine-Tails",
     "new WhipItem(2, -1.2F, 6, p())", (90, 55, 35), "tool"),
    ("mazzafrusto", "Mazzafrusto", "Flail", "new SwordItem(Tiers.IRON, 5, -3.1F, p())", (140, 140, 145), "tool"),
    ("mazza_ferrata", "Mazza ferrata", "Flanged Mace", "new SwordItem(Tiers.IRON, 3, -2.8F, p())", (150, 150, 155), "tool"),
    ("stella_del_mattino", "Stella del mattino", "Morning Star", "new SwordItem(Tiers.IRON, 4, -2.9F, p())", (130, 130, 135), "tool"),
    ("spada_del_boia", "Spada del boia", "Executioner's Sword", "new SwordItem(Tiers.IRON, 5, -2.6F, p())", (190, 190, 200), "tool"),
    ("ascia_del_boia", "Ascia del boia", "Executioner's Axe", "new AxeItem(Tiers.IRON, 8.0F, -3.2F, p())", (170, 170, 180), "tool"),
]

# --- Strumenti da usare su una creatura (tasto destro): id, it, en, java, colore
INSTRUMENTS = [
    ("tenaglie_roventi", "Tenaglie roventi", "Red-Hot Pincers",
     "new TortureToolItem(p().durability(64), null, 0, 0, 4)", (200, 90, 40)),
    ("pollici", "Pollici (stringipollici)", "Thumbscrews",
     "new TortureToolItem(p().durability(64), () -> MobEffects.MOVEMENT_SLOWDOWN, 8, 1, 0)", (140, 140, 145)),
    ("pera_dell_angoscia", "Pera dell'angoscia", "Pear of Anguish",
     "new TortureToolItem(p().durability(48), () -> MobEffects.CONFUSION, 8, 0, 0)", (160, 140, 80)),
    ("ferro_da_marchio", "Ferro da marchio", "Branding Iron",
     "new TortureToolItem(p().durability(48), null, 0, 0, 6)", (190, 70, 40)),
    ("manette", "Manette di ferro", "Iron Shackles",
     "new TortureToolItem(p().durability(100), () -> MobEffects.MOVEMENT_SLOWDOWN, 15, 3, 0)", (120, 120, 125)),
    ("corda_del_boia", "Corda del boia", "Hangman's Noose",
     "new TortureToolItem(p().durability(80), () -> MobEffects.MOVEMENT_SLOWDOWN, 10, 2, 0)", (170, 140, 90)),
]

# --- Macchine di tortura (blocchi): id, it, en, effetto, metallo, nota IT, nota EN, colore
BLOCKS = [
    ("ruota_del_supplizio", "Ruota del supplizio", "Breaking Wheel", "IMMOBILIZE_WEAKEN", False,
     "La ruota: il condannato veniva legato e gli arti spezzati con una mazza. Diffusa soprattutto nell'Europa centrale.",
     "The breaking wheel: the condemned was bound and had their limbs broken with a club. Common in central Europe.",
     (120, 85, 50)),
    ("cavalletto", "Cavalletto (il rack)", "The Rack", "IMMOBILIZE_WEAKEN", False,
     "Il cavalletto: un telaio con rulli che stirava il corpo del prigioniero. Celebre nell'Inghilterra Tudor.",
     "The rack: a frame with rollers that stretched the prisoner's body. Famous in Tudor England.",
     (110, 80, 50)),
    ("vergine_di_ferro", "Vergine di ferro", "Iron Maiden", "DAMAGE", True,
     "La vergine di ferro: sarcofago con punte interne. Nota soprattutto come leggenda, forse invenzione del XVIII secolo.",
     "The iron maiden: a spiked cabinet. Mostly legend, probably an 18th-century invention.",
     (130, 130, 138)),
    ("gogna", "Gogna", "Pillory", "IMMOBILIZE", False,
     "La gogna: il condannato era esposto in piazza, bloccato per testa e mani, alla derisione e agli oggetti lanciati dalla folla.",
     "The pillory: the condemned was displayed in the square, locked by head and hands, to public mockery.",
     (125, 90, 55)),
    ("ceppi", "Ceppi", "Stocks", "IMMOBILIZE", False,
     "I ceppi: assi di legno che bloccavano piedi e talvolta mani. Pena comune per ubriachezza e piccoli reati.",
     "The stocks: wooden boards that locked feet and sometimes hands. A common penalty for drunkenness and petty crime.",
     (115, 85, 52)),
    ("ghigliottina", "Ghigliottina", "Guillotine", "NONE", False,
     "La ghigliottina: in uso in Francia dal 1792, dunque oltre il Medioevo. Prima esistevano macchine simili come la Halifax Gibbet.",
     "The guillotine: used in France from 1792, after the Middle Ages. Earlier machines like the Halifax Gibbet were similar.",
     (100, 70, 45)),
    ("forca", "Forca", "Gallows", "NONE", False,
     "La forca: l'impiccagione era la pena capitale più diffusa nel Medioevo; i corpi restavano esposti come monito.",
     "The gallows: hanging was the most common capital punishment; bodies were left on display as a warning.",
     (105, 75, 48)),
    ("gabbia_sospesa", "Gabbia sospesa", "Gibbet Cage", "IMMOBILIZE", True,
     "La gabbia sospesa: il condannato era chiuso in una gabbia di ferro appesa in pubblico, spesso fino alla morte.",
     "The gibbet cage: the condemned was locked in an iron cage hung in public, often until death.",
     (110, 110, 118)),
    ("sedia_dei_chiodi", "Sedia dei chiodi (sedia di Giuda)", "Chair of Nails", "DAMAGE", True,
     "La sedia dei chiodi: sedile ricoperto di punte usato negli interrogatori, spesso ricordato in racconti tardo-medievali.",
     "The chair of nails: a seat covered in spikes used for interrogation, often described in late-medieval accounts.",
     (120, 100, 90)),
    ("sgabello_dell_annegamento", "Sgabello dell'annegamento", "Ducking Stool", "NONE", False,
     "Lo sgabello dell'annegamento: la persona veniva immersa ripetutamente in acqua. Punizione per 'linguacce' e frodi.",
     "The ducking stool: the person was repeatedly dunked in water. Punishment for scolds and cheats.",
     (90, 85, 70)),
    ("culla_di_giuda", "Culla di Giuda", "Judas Cradle", "DAMAGE", False,
     "La culla di Giuda: seggiolino a piramide su cui veniva calata la vittima. Attestata soprattutto in Europa tra XVI e XVII secolo.",
     "The Judas cradle: a pyramid-shaped seat onto which the victim was lowered. Attested mainly in 16th-17th century Europe.",
     (100, 78, 55)),
    ("toro_di_falaride", "Toro di Falaride", "Brazen Bull", "FIRE", True,
     "Il toro di Falaride: toro di bronzo cavo, riscaldato dall'esterno. Origine dall'antica Grecia, ricordato anche nel Medioevo.",
     "The brazen bull: a hollow bronze bull heated from outside. Of ancient Greek origin, remembered in the Middle Ages.",
     (160, 110, 50)),
    ("strappado", "Strappado", "Strappado", "IMMOBILIZE_WEAKEN", False,
     "Lo strappado: il prigioniero veniva sollevato con una corda legata ai polsi dietro la schiena. Molto usato dall'Inquisizione.",
     "The strappado: the prisoner was hoisted by a rope tied to wrists behind the back. Widely used by inquisitors.",
     (115, 85, 55)),
    ("cavallo_di_legno", "Cavallo di legno", "Wooden Horse", "IMMOBILIZE", False,
     "Il cavallo di legno: trave dal bordo a spigolo su cui il condannato restava a cavalcioni, spesso con pesi ai piedi.",
     "The wooden horse: a sharp-edged beam on which the condemned sat astride, often with weights on the feet.",
     (120, 88, 55)),
    ("oubliette", "Oubliette (cella-pozzo)", "Oubliette", "IMMOBILIZE", False,
     "L'oubliette: cella a pozzo accessibile solo da una botola nel soffitto; il prigioniero veniva 'dimenticato' laggiù.",
     "The oubliette: a pit cell reached only by a trapdoor in the ceiling; the prisoner was 'forgotten' there.",
     (70, 65, 60)),
    ("ceppo_del_boia", "Ceppo del boia", "Executioner's Block", "NONE", False,
     "Il ceppo del boia: il tronco su cui il condannato poggiava la testa per la decapitazione con ascia o spada.",
     "The executioner's block: the stump on which the condemned rested the head for beheading by axe or sword.",
     (95, 68, 42)),
    ("braciere_ferri_roventi", "Braciere con ferri roventi", "Brazier with Hot Irons", "FIRE", True,
     "Il braciere: teneva al calore tenaglie e ferri da marchio. Presente in ogni camera degli interrogatori.",
     "The brazier: kept pincers and branding irons hot. Found in every interrogation chamber.",
     (170, 80, 40)),
    ("tavolo_degli_interrogatori", "Tavolo degli interrogatori", "Interrogation Table", "IMMOBILIZE", False,
     "Il tavolo degli interrogatori: tavolo robusto con anelli per legare il prigioniero durante l'esame.",
     "The interrogation table: a sturdy table with rings to bind the prisoner during questioning.",
     (105, 78, 50)),
    ("letto_di_chiodi", "Letto di chiodi", "Bed of Nails", "DAMAGE", True,
     "Il letto di chiodi: asse o letto irto di punte, citato nelle cronache come strumento di coercizione.",
     "The bed of nails: a plank or bed bristling with spikes, cited in chronicles as an instrument of coercion.",
     (115, 110, 105)),
]

# ---------------------------------------------------------------- ricette
LEATHER = "minecraft:leather"
STICK = "minecraft:stick"
IRON = "minecraft:iron_ingot"


def item(i):
    return {"item": i}


def shaped(result, pattern, key, count=1):
    return {"type": "minecraft:crafting_shaped", "category": "misc", "pattern": pattern,
            "key": {k: item(v) for k, v in key.items()},
            "result": {"item": f"{MOD}:{result}", "count": count}}


def shapeless(result, ings, count=1):
    return {"type": "minecraft:crafting_shapeless", "category": "misc",
            "ingredients": [item(i) for i in ings],
            "result": {"item": f"{MOD}:{result}", "count": count}}


def stonecut(result, ing):
    return {"type": "minecraft:stonecutting", "ingredient": item(ing),
            "result": f"{MOD}:{result}", "count": 1}


RECIPES = {}

# Cibi
RECIPES["pane_nero"] = shapeless("pane_nero", ["minecraft:wheat", "minecraft:wheat", "minecraft:brown_mushroom"])
RECIPES["pane_bianco"] = shapeless("pane_bianco", ["minecraft:bread", "minecraft:egg"])
RECIPES["zuppa_di_porri"] = shapeless("zuppa_di_porri", ["minecraft:bowl", "minecraft:potato", "minecraft:carrot", "minecraft:beetroot"])
RECIPES["stufato_di_cinghiale"] = shapeless("stufato_di_cinghiale", ["minecraft:bowl", "minecraft:porkchop", "minecraft:potato", "minecraft:carrot"])
RECIPES["cinghiale_arrosto"] = shapeless("cinghiale_arrosto", ["minecraft:cooked_porkchop", "minecraft:apple"])
RECIPES["salsiccia"] = shapeless("salsiccia", ["minecraft:porkchop", "minecraft:beef", "minecraft:string"], 2)
RECIPES["formaggio_stagionato"] = shapeless("formaggio_stagionato", ["minecraft:milk_bucket", "minecraft:wheat"], 2)
RECIPES["torta_di_carne"] = shapeless("torta_di_carne", ["minecraft:wheat", "minecraft:wheat", "minecraft:wheat", "minecraft:beef", "minecraft:potato"])
RECIPES["torta_di_mele"] = shapeless("torta_di_mele", ["minecraft:apple", "minecraft:apple", "minecraft:wheat", "minecraft:egg", "minecraft:sugar"])
RECIPES["pollo_arrosto"] = shapeless("pollo_arrosto", ["minecraft:cooked_chicken", "minecraft:carrot"])
RECIPES["pesce_affumicato"] = {"type": "minecraft:smoking", "category": "food", "ingredient": item("minecraft:cod"),
                               "result": f"{MOD}:pesce_affumicato", "experience": 0.35, "cookingtime": 100}
RECIPES["aringa_salata"] = shapeless("aringa_salata", ["minecraft:cod", "minecraft:bone_meal"])
RECIPES["pottage"] = shapeless("pottage", ["minecraft:bowl", "minecraft:wheat", "minecraft:wheat", "minecraft:carrot"])
RECIPES["idromele"] = shapeless("idromele", ["minecraft:honey_bottle", "minecraft:wheat"])
RECIPES["birra_medievale"] = shapeless("birra_medievale", ["minecraft:water_bucket", "minecraft:wheat", "minecraft:wheat", "minecraft:wheat"], 2)
RECIPES["ipocrasso"] = shapeless("ipocrasso", ["minecraft:honey_bottle", "minecraft:sweet_berries", "minecraft:sugar"])

# Abiti
SETS = {
    "contadino": ("minecraft:white_wool", "minecraft:white_wool", "minecraft:white_wool", "minecraft:white_wool"),
    "nobile": ("minecraft:purple_wool",) * 4,
    "monaco": ("minecraft:brown_wool",) * 4,
    "boia": ("minecraft:black_wool",) * 4,
}
WOOL = {"contadino": "minecraft:white_wool", "nobile": "minecraft:purple_wool",
        "monaco": "minecraft:brown_wool", "boia": "minecraft:black_wool"}
for s, wool in WOOL.items():
    names = {c[4]: c[0] for c in CLOTHES if c[3] == s.upper()}
    RECIPES[names["HELMET"]] = shaped(names["HELMET"], ["WWW", "W W"], {"W": wool})
    RECIPES[names["CHESTPLATE"]] = shaped(names["CHESTPLATE"], ["W W", "WWW", "WWW"], {"W": wool})
    RECIPES[names["LEGGINGS"]] = shaped(names["LEGGINGS"], ["WWW", "W W", "W W"], {"W": wool})
    RECIPES[names["BOOTS"]] = shaped(names["BOOTS"], ["W W", "L L"], {"W": wool, "L": LEATHER})
RECIPES["maschera_della_vergogna"] = shaped("maschera_della_vergogna", ["III", "I I", " N "],
                                            {"I": IRON, "N": "minecraft:iron_nugget"})
RECIPES["stivale_spagnolo"] = shaped("stivale_spagnolo", ["I I", "I I", "NNN"],
                                     {"I": IRON, "N": "minecraft:iron_nugget"})

# Armi
RECIPES["frusta"] = shaped("frusta", ["  L", " L ", "S  "], {"L": LEATHER, "S": STICK})
RECIPES["gatto_a_nove_code"] = shaped("gatto_a_nove_code", ["LLL", "L L", " S "], {"L": LEATHER, "S": STICK})
RECIPES["mazzafrusto"] = shaped("mazzafrusto", ["  I", " C ", "S  "], {"I": IRON, "C": "minecraft:chain", "S": STICK})
RECIPES["mazza_ferrata"] = shaped("mazza_ferrata", [" I ", "ISI", " S "], {"I": IRON, "S": STICK})
RECIPES["stella_del_mattino"] = shaped("stella_del_mattino", [" N ", "NIN", " S "],
                                       {"N": "minecraft:iron_nugget", "I": IRON, "S": STICK})
RECIPES["spada_del_boia"] = shaped("spada_del_boia", [" I ", " I ", "ISI"], {"I": IRON, "S": STICK})
RECIPES["ascia_del_boia"] = shaped("ascia_del_boia", ["II ", "IS ", "IS "], {"I": IRON, "S": STICK})

# Strumenti
RECIPES["tenaglie_roventi"] = shaped("tenaglie_roventi", ["I I", " I ", "S S"], {"I": IRON, "S": STICK})
RECIPES["pollici"] = shaped("pollici", ["II", "IN"], {"I": IRON, "N": "minecraft:iron_nugget"})
RECIPES["pera_dell_angoscia"] = shaped("pera_dell_angoscia", [" I ", "IAI", " I "], {"I": IRON, "A": "minecraft:apple"})
RECIPES["ferro_da_marchio"] = shaped("ferro_da_marchio", ["C", "I", "S"], {"C": "minecraft:coal", "I": IRON, "S": STICK})
RECIPES["manette"] = shaped("manette", ["III", "C C"], {"I": IRON, "C": "minecraft:chain"})
RECIPES["corda_del_boia"] = shaped("corda_del_boia", [" S ", "S S", " S "], {"S": "minecraft:string"})

# Macchine: tagliapietre da assi di quercia (legno) o blocco di ferro (metallo)
for b in BLOCKS:
    RECIPES[b[0]] = stonecut(b[0], "minecraft:iron_block" if b[4] else "minecraft:oak_planks")


# ---------------------------------------------------------------- Java
def gen_items_java():
    lines = []

    def reg(name, expr):
        lines.append(f'    public static final RegistryObject<Item> {name.upper()} = reg("{name}", () -> {expr});')

    for (i, _, _, nut, sat, kind, _c) in FOODS:
        f = f"new FoodProperties.Builder().nutrition({nut}).saturationMod({sat}F).build()"
        if kind == "bowl":
            reg(i, f"new BowlFoodItem(p().stacksTo(1).food({f}))")
        else:
            reg(i, f"new Item(p().food({f}))")
    for (i, _, _, builder, _c) in DRINKS:
        reg(i, f"new DrinkItem(p().stacksTo(16).food({builder}))")
    for (i, _, _, mat, slot, _c) in CLOTHES:
        reg(i, f"new ArmorItem(ModArmorMaterials.{mat}, ArmorItem.Type.{slot}, p())")
    for (i, _, _, expr, _c, _k) in WEAPONS:
        reg(i, expr)
    for (i, _, _, expr, _c) in INSTRUMENTS:
        reg(i, expr)

    body = "\n".join(lines)
    src = f'''package com.medievalcraft.item;

import com.medievalcraft.MedievalCraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.*;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

// FILE GENERATO da tools/generate.py - modifica la tabella nello script, non questo file.
public class ModItems {{
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MedievalCraft.MODID);

    private static Item.Properties p() {{
        return new Item.Properties();
    }}

    private static RegistryObject<Item> reg(String name, Supplier<Item> supplier) {{
        return ITEMS.register(name, supplier);
    }}

{body}
}}
'''
    wf(f"{JAVA}/item/ModItems.java", src)


def gen_blocks_java():
    calls = "\n".join(
        f'        dev("{b[0]}", TortureBlock.Effect.{b[3]}, {"true" if b[4] else "false"});' for b in BLOCKS)
    src = f'''package com.medievalcraft.block;

import com.medievalcraft.MedievalCraft;
import com.medievalcraft.item.ModItems;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

// FILE GENERATO da tools/generate.py - modifica la tabella nello script, non questo file.
public class ModBlocks {{
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, MedievalCraft.MODID);

    private static void dev(String name, TortureBlock.Effect effect, boolean metal) {{
        BlockBehaviour.Properties props = BlockBehaviour.Properties.of()
                .strength(metal ? 5.0F : 2.5F, 6.0F)
                .sound(metal ? SoundType.METAL : SoundType.WOOD);
        if (effect != TortureBlock.Effect.NONE) {{
            props = props.noCollission();
        }}
        final BlockBehaviour.Properties finalProps = props;
        RegistryObject<Block> block = BLOCKS.register(name,
                () -> new TortureBlock(finalProps, effect, "info.medievalcraft." + name));
        ModItems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
    }}

    static {{
{calls}
    }}
}}
'''
    wf(f"{JAVA}/block/ModBlocks.java", src)


# ---------------------------------------------------------------- texture
def item_shape(kind):
    s = set()

    def rect(x0, y0, x1, y1):
        for x in range(x0, x1 + 1):
            for y in range(y0, y1 + 1):
                s.add((x, y))

    if kind == "HELMET":
        rect(3, 4, 12, 9); rect(3, 10, 5, 12); rect(10, 10, 12, 12)
    elif kind == "CHESTPLATE":
        rect(4, 3, 11, 13); rect(1, 3, 3, 8); rect(12, 3, 14, 8)
    elif kind == "LEGGINGS":
        rect(4, 2, 11, 5); rect(4, 6, 6, 14); rect(9, 6, 11, 14)
    elif kind == "BOOTS":
        rect(3, 6, 6, 12); rect(3, 12, 7, 13); rect(9, 6, 12, 12); rect(9, 12, 13, 13)
    elif kind in ("food", "bowl"):
        for x in range(16):
            for y in range(16):
                if (x - 7.5) ** 2 + (y - 7.5) ** 2 <= 32:
                    s.add((x, y))
        if kind == "bowl":
            rect(3, 11, 12, 13)
    elif kind == "drink":
        rect(6, 2, 9, 4); rect(5, 5, 10, 14)
    elif kind == "tool":
        for i in range(2, 14):
            s.add((i, 15 - i)); s.add((i + 1, 15 - i))
        rect(9, 1, 14, 5)
    else:
        rect(4, 4, 11, 11)
    return s


def gen_item_texture(name, kind, color):
    s = item_shape(kind)

    def pix(x, y):
        if (x, y) not in s:
            return (0, 0, 0, 0)
        edge = any((x + dx, y + dy) not in s for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))
        base = shade(color, -45) if edge else shade(color, noise(name, x, y, 12))
        return base + (255,)

    png(f"{ASSETS}/textures/item/{name}.png", 16, 16, pix)


def gen_block_texture(name, color, metal):
    def pix(x, y):
        if metal:
            c = shade(color, noise(name, x, y, 8))
            if x in (0, 15) or y in (0, 15):
                c = shade(color, -40)
            if (x, y) in ((2, 2), (13, 2), (2, 13), (13, 13)):
                c = shade(color, 40)
            if x % 4 == 0 and 2 < y < 13:
                c = shade(color, -20)
        else:
            c = shade(color, noise(name, x, y, 10))
            if y % 4 == 0:
                c = shade(color, -35)
            if x == 0 or x == 15:
                c = shade(color, -25)
        return c + (255,)

    png(f"{ASSETS}/textures/block/{name}.png", 16, 16, pix)


def gen_armor_layers():
    layers = {"contadino": (200, 190, 160), "nobile": (110, 40, 130), "monaco": (110, 80, 50),
              "boia": (35, 33, 38), "tortura": (140, 140, 145)}
    for name, color in layers.items():
        for n in (1, 2):
            def pix(x, y, name=name, color=color, n=n):
                c = shade(color, noise(f"{name}{n}", x, y, 12))
                if (x + y) % 8 == 0:
                    c = shade(c, -18)
                return c + (255,)
            png(f"{ASSETS}/textures/models/armor/{name}_layer_{n}.png", 64, 32, pix)


# ---------------------------------------------------------------- risorse
def gen_models_and_states():
    for (i, *_rest) in FOODS:
        wj(f"{ASSETS}/models/item/{i}.json",
           {"parent": "item/generated", "textures": {"layer0": f"{MOD}:item/{i}"}})
    for (i, *_rest) in DRINKS:
        wj(f"{ASSETS}/models/item/{i}.json",
           {"parent": "item/generated", "textures": {"layer0": f"{MOD}:item/{i}"}})
    for (i, *_rest) in CLOTHES:
        wj(f"{ASSETS}/models/item/{i}.json",
           {"parent": "item/generated", "textures": {"layer0": f"{MOD}:item/{i}"}})
    for (i, *_rest) in WEAPONS + INSTRUMENTS:
        wj(f"{ASSETS}/models/item/{i}.json",
           {"parent": "item/handheld", "textures": {"layer0": f"{MOD}:item/{i}"}})
    for b in BLOCKS:
        i = b[0]
        wj(f"{ASSETS}/blockstates/{i}.json", {"variants": {"": {"model": f"{MOD}:block/{i}"}}})
        wj(f"{ASSETS}/models/block/{i}.json",
           {"parent": "minecraft:block/cube_all", "textures": {"all": f"{MOD}:block/{i}"}})
        wj(f"{ASSETS}/models/item/{i}.json", {"parent": f"{MOD}:block/{i}"})
        wj(f"{DATA}/loot_tables/blocks/{i}.json", {
            "type": "minecraft:block",
            "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"{MOD}:{i}"}],
                       "conditions": [{"condition": "minecraft:survives_explosion"}]}]})


def gen_textures():
    for (i, _, _, _, _, kind, color) in FOODS:
        gen_item_texture(i, kind, color)
    for (i, _, _, _, color) in DRINKS:
        gen_item_texture(i, "drink", color)
    for (i, _, _, _, slot, color) in CLOTHES:
        gen_item_texture(i, slot, color)
    for (i, _, _, _, color, kind) in WEAPONS:
        gen_item_texture(i, kind, color)
    for (i, _, _, _, color) in INSTRUMENTS:
        gen_item_texture(i, "tool", color)
    for b in BLOCKS:
        gen_block_texture(b[0], b[7], b[4])
    gen_armor_layers()


def gen_lang():
    it = {"itemGroup.medievalcraft": "MedievalCraft - Medioevo"}
    en = {"itemGroup.medievalcraft": "MedievalCraft - Middle Ages"}
    for (i, n_it, n_en, *_r) in FOODS:
        it[f"item.{MOD}.{i}"] = n_it; en[f"item.{MOD}.{i}"] = n_en
    for (i, n_it, n_en, *_r) in DRINKS:
        it[f"item.{MOD}.{i}"] = n_it; en[f"item.{MOD}.{i}"] = n_en
    for (i, n_it, n_en, *_r) in CLOTHES:
        it[f"item.{MOD}.{i}"] = n_it; en[f"item.{MOD}.{i}"] = n_en
    for (i, n_it, n_en, *_r) in WEAPONS + INSTRUMENTS:
        it[f"item.{MOD}.{i}"] = n_it; en[f"item.{MOD}.{i}"] = n_en
    for b in BLOCKS:
        i = b[0]
        it[f"block.{MOD}.{i}"] = b[1]; en[f"block.{MOD}.{i}"] = b[2]
        it[f"info.{MOD}.{i}"] = b[5]; en[f"info.{MOD}.{i}"] = b[6]
    wj(f"{ASSETS}/lang/it_it.json", it)
    wj(f"{ASSETS}/lang/en_us.json", en)


def gen_recipes_and_tags():
    for name, r in RECIPES.items():
        wj(f"{DATA}/recipes/{name}.json", r)
    wood = [f"{MOD}:{b[0]}" for b in BLOCKS if not b[4]]
    metal = [f"{MOD}:{b[0]}" for b in BLOCKS if b[4]]
    wj(f"{ROOT}/src/main/resources/data/minecraft/tags/blocks/mineable/axe.json", {"replace": False, "values": wood})
    wj(f"{ROOT}/src/main/resources/data/minecraft/tags/blocks/mineable/pickaxe.json", {"replace": False, "values": metal})


if __name__ == "__main__":
    gen_items_java()
    gen_blocks_java()
    gen_models_and_states()
    gen_textures()
    gen_lang()
    gen_recipes_and_tags()
    total_items = len(FOODS) + len(DRINKS) + len(CLOTHES) + len(WEAPONS) + len(INSTRUMENTS)
    print(f"OK: {total_items} oggetti, {len(BLOCKS)} macchine, {len(RECIPES)} ricette")
