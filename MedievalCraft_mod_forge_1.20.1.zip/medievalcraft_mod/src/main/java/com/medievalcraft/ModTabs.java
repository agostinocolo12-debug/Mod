package com.medievalcraft;

import com.medievalcraft.item.ModItems;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MedievalCraft.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("medioevo",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.medievalcraft"))
                    .icon(() -> new ItemStack(ModItems.ASCIA_DEL_BOIA.get()))
                    .displayItems((params, output) ->
                            ModItems.ITEMS.getEntries().forEach(e -> output.accept(e.get())))
                    .build());
}
