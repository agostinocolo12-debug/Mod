package com.medievalcraft.item;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;

/** Frusta / gatto a nove code: veloce, danno basso, rallenta e indebolisce il bersaglio. */
public class WhipItem extends SwordItem {
    private final int effectSeconds;

    public WhipItem(int damage, float speed, int effectSeconds, Properties properties) {
        super(Tiers.WOOD, damage, speed, properties);
        this.effectSeconds = effectSeconds;
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, effectSeconds * 20, 0));
        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, effectSeconds * 20, 0));
        return super.hurtEnemy(stack, target, attacker);
    }
}
