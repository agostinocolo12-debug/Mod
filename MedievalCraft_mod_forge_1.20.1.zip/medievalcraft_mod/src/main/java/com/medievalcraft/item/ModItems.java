package com.medievalcraft.item;

import com.medievalcraft.MedievalCraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.*;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

// FILE GENERATO da tools/generate.py - modifica la tabella nello script, non questo file.
public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MedievalCraft.MODID);

    private static Item.Properties p() {
        return new Item.Properties();
    }

    private static RegistryObject<Item> reg(String name, Supplier<Item> supplier) {
        return ITEMS.register(name, supplier);
    }

    public static final RegistryObject<Item> PANE_NERO = reg("pane_nero", () -> new Item(p().food(new FoodProperties.Builder().nutrition(5).saturationMod(0.6F).build())));
    public static final RegistryObject<Item> PANE_BIANCO = reg("pane_bianco", () -> new Item(p().food(new FoodProperties.Builder().nutrition(6).saturationMod(0.7F).build())));
    public static final RegistryObject<Item> ZUPPA_DI_PORRI = reg("zuppa_di_porri", () -> new BowlFoodItem(p().stacksTo(1).food(new FoodProperties.Builder().nutrition(6).saturationMod(0.6F).build())));
    public static final RegistryObject<Item> STUFATO_DI_CINGHIALE = reg("stufato_di_cinghiale", () -> new BowlFoodItem(p().stacksTo(1).food(new FoodProperties.Builder().nutrition(10).saturationMod(0.8F).build())));
    public static final RegistryObject<Item> CINGHIALE_ARROSTO = reg("cinghiale_arrosto", () -> new Item(p().food(new FoodProperties.Builder().nutrition(9).saturationMod(0.9F).build())));
    public static final RegistryObject<Item> SALSICCIA = reg("salsiccia", () -> new Item(p().food(new FoodProperties.Builder().nutrition(6).saturationMod(0.6F).build())));
    public static final RegistryObject<Item> FORMAGGIO_STAGIONATO = reg("formaggio_stagionato", () -> new Item(p().food(new FoodProperties.Builder().nutrition(4).saturationMod(0.5F).build())));
    public static final RegistryObject<Item> TORTA_DI_CARNE = reg("torta_di_carne", () -> new Item(p().food(new FoodProperties.Builder().nutrition(8).saturationMod(0.7F).build())));
    public static final RegistryObject<Item> TORTA_DI_MELE = reg("torta_di_mele", () -> new Item(p().food(new FoodProperties.Builder().nutrition(7).saturationMod(0.5F).build())));
    public static final RegistryObject<Item> POLLO_ARROSTO = reg("pollo_arrosto", () -> new Item(p().food(new FoodProperties.Builder().nutrition(8).saturationMod(0.8F).build())));
    public static final RegistryObject<Item> PESCE_AFFUMICATO = reg("pesce_affumicato", () -> new Item(p().food(new FoodProperties.Builder().nutrition(6).saturationMod(0.7F).build())));
    public static final RegistryObject<Item> ARINGA_SALATA = reg("aringa_salata", () -> new Item(p().food(new FoodProperties.Builder().nutrition(4).saturationMod(0.4F).build())));
    public static final RegistryObject<Item> POTTAGE = reg("pottage", () -> new BowlFoodItem(p().stacksTo(1).food(new FoodProperties.Builder().nutrition(7).saturationMod(0.6F).build())));
    public static final RegistryObject<Item> IDROMELE = reg("idromele", () -> new DrinkItem(p().stacksTo(16).food(new FoodProperties.Builder().nutrition(2).saturationMod(0.3F).alwaysEat().effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 0), 1.0F).build())));
    public static final RegistryObject<Item> BIRRA_MEDIEVALE = reg("birra_medievale", () -> new DrinkItem(p().stacksTo(16).food(new FoodProperties.Builder().nutrition(3).saturationMod(0.3F).alwaysEat().effect(() -> new MobEffectInstance(MobEffects.CONFUSION, 120, 0), 0.25F).build())));
    public static final RegistryObject<Item> IPOCRASSO = reg("ipocrasso", () -> new DrinkItem(p().stacksTo(16).food(new FoodProperties.Builder().nutrition(2).saturationMod(0.3F).alwaysEat().effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 600, 0), 1.0F).effect(() -> new MobEffectInstance(MobEffects.CONFUSION, 100, 0), 0.3F).build())));
    public static final RegistryObject<Item> CONTADINO_CAPPUCCIO = reg("contadino_cappuccio", () -> new ArmorItem(ModArmorMaterials.CONTADINO, ArmorItem.Type.HELMET, p()));
    public static final RegistryObject<Item> CONTADINO_TUNICA = reg("contadino_tunica", () -> new ArmorItem(ModArmorMaterials.CONTADINO, ArmorItem.Type.CHESTPLATE, p()));
    public static final RegistryObject<Item> CONTADINO_CALZONI = reg("contadino_calzoni", () -> new ArmorItem(ModArmorMaterials.CONTADINO, ArmorItem.Type.LEGGINGS, p()));
    public static final RegistryObject<Item> CONTADINO_SCARPE = reg("contadino_scarpe", () -> new ArmorItem(ModArmorMaterials.CONTADINO, ArmorItem.Type.BOOTS, p()));
    public static final RegistryObject<Item> NOBILE_CAPPELLO = reg("nobile_cappello", () -> new ArmorItem(ModArmorMaterials.NOBILE, ArmorItem.Type.HELMET, p()));
    public static final RegistryObject<Item> NOBILE_FARSETTO = reg("nobile_farsetto", () -> new ArmorItem(ModArmorMaterials.NOBILE, ArmorItem.Type.CHESTPLATE, p()));
    public static final RegistryObject<Item> NOBILE_CALZE = reg("nobile_calze", () -> new ArmorItem(ModArmorMaterials.NOBILE, ArmorItem.Type.LEGGINGS, p()));
    public static final RegistryObject<Item> NOBILE_POULAINES = reg("nobile_poulaines", () -> new ArmorItem(ModArmorMaterials.NOBILE, ArmorItem.Type.BOOTS, p()));
    public static final RegistryObject<Item> MONACO_CAPPUCCIO = reg("monaco_cappuccio", () -> new ArmorItem(ModArmorMaterials.MONACO, ArmorItem.Type.HELMET, p()));
    public static final RegistryObject<Item> MONACO_TONACA = reg("monaco_tonaca", () -> new ArmorItem(ModArmorMaterials.MONACO, ArmorItem.Type.CHESTPLATE, p()));
    public static final RegistryObject<Item> MONACO_BRACHE = reg("monaco_brache", () -> new ArmorItem(ModArmorMaterials.MONACO, ArmorItem.Type.LEGGINGS, p()));
    public static final RegistryObject<Item> MONACO_SANDALI = reg("monaco_sandali", () -> new ArmorItem(ModArmorMaterials.MONACO, ArmorItem.Type.BOOTS, p()));
    public static final RegistryObject<Item> BOIA_CAPPUCCIO = reg("boia_cappuccio", () -> new ArmorItem(ModArmorMaterials.BOIA, ArmorItem.Type.HELMET, p()));
    public static final RegistryObject<Item> BOIA_GIUBBA = reg("boia_giubba", () -> new ArmorItem(ModArmorMaterials.BOIA, ArmorItem.Type.CHESTPLATE, p()));
    public static final RegistryObject<Item> BOIA_PANTALONI = reg("boia_pantaloni", () -> new ArmorItem(ModArmorMaterials.BOIA, ArmorItem.Type.LEGGINGS, p()));
    public static final RegistryObject<Item> BOIA_STIVALI = reg("boia_stivali", () -> new ArmorItem(ModArmorMaterials.BOIA, ArmorItem.Type.BOOTS, p()));
    public static final RegistryObject<Item> MASCHERA_DELLA_VERGOGNA = reg("maschera_della_vergogna", () -> new ArmorItem(ModArmorMaterials.TORTURA, ArmorItem.Type.HELMET, p()));
    public static final RegistryObject<Item> STIVALE_SPAGNOLO = reg("stivale_spagnolo", () -> new ArmorItem(ModArmorMaterials.TORTURA, ArmorItem.Type.BOOTS, p()));
    public static final RegistryObject<Item> FRUSTA = reg("frusta", () -> new WhipItem(1, -1.0F, 4, p()));
    public static final RegistryObject<Item> GATTO_A_NOVE_CODE = reg("gatto_a_nove_code", () -> new WhipItem(2, -1.2F, 6, p()));
    public static final RegistryObject<Item> MAZZAFRUSTO = reg("mazzafrusto", () -> new SwordItem(Tiers.IRON, 5, -3.1F, p()));
    public static final RegistryObject<Item> MAZZA_FERRATA = reg("mazza_ferrata", () -> new SwordItem(Tiers.IRON, 3, -2.8F, p()));
    public static final RegistryObject<Item> STELLA_DEL_MATTINO = reg("stella_del_mattino", () -> new SwordItem(Tiers.IRON, 4, -2.9F, p()));
    public static final RegistryObject<Item> SPADA_DEL_BOIA = reg("spada_del_boia", () -> new SwordItem(Tiers.IRON, 5, -2.6F, p()));
    public static final RegistryObject<Item> ASCIA_DEL_BOIA = reg("ascia_del_boia", () -> new AxeItem(Tiers.IRON, 8.0F, -3.2F, p()));
    public static final RegistryObject<Item> TENAGLIE_ROVENTI = reg("tenaglie_roventi", () -> new TortureToolItem(p().durability(64), null, 0, 0, 4));
    public static final RegistryObject<Item> POLLICI = reg("pollici", () -> new TortureToolItem(p().durability(64), () -> MobEffects.MOVEMENT_SLOWDOWN, 8, 1, 0));
    public static final RegistryObject<Item> PERA_DELL_ANGOSCIA = reg("pera_dell_angoscia", () -> new TortureToolItem(p().durability(48), () -> MobEffects.CONFUSION, 8, 0, 0));
    public static final RegistryObject<Item> FERRO_DA_MARCHIO = reg("ferro_da_marchio", () -> new TortureToolItem(p().durability(48), null, 0, 0, 6));
    public static final RegistryObject<Item> MANETTE = reg("manette", () -> new TortureToolItem(p().durability(100), () -> MobEffects.MOVEMENT_SLOWDOWN, 15, 3, 0));
    public static final RegistryObject<Item> CORDA_DEL_BOIA = reg("corda_del_boia", () -> new TortureToolItem(p().durability(80), () -> MobEffects.MOVEMENT_SLOWDOWN, 10, 2, 0));
}
