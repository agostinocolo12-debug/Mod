package com.medievalcraft.item;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.function.Supplier;

/** Strumento da usare con il tasto destro su una creatura: danno lieve + effetto. */
public class TortureToolItem extends Item {
    private final Supplier<MobEffect> effect;
    private final int seconds;
    private final int amplifier;
    private final int fireSeconds;

    public TortureToolItem(Properties properties, Supplier<MobEffect> effect, int seconds, int amplifier, int fireSeconds) {
        super(properties);
        this.effect = effect;
        this.seconds = seconds;
        this.amplifier = amplifier;
        this.fireSeconds = fireSeconds;
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (!player.level().isClientSide) {
            target.hurt(player.damageSources().playerAttack(player), 2.0F);
            if (effect != null) {
                target.addEffect(new MobEffectInstance(effect.get(), seconds * 20, amplifier));
            }
            if (fireSeconds > 0) {
                target.setSecondsOnFire(fireSeconds);
            }
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
        }
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }
}
