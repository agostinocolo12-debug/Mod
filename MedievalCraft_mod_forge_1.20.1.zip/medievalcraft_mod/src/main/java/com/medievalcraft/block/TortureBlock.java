package com.medievalcraft.block;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Macchina/strumento medievale. Le macchine "trappola" non hanno collisione:
 * chi vi entra viene trattenuto o subisce l'effetto. Tasto destro a mano vuota
 * mostra una breve nota storica.
 */
public class TortureBlock extends Block {

    public enum Effect { NONE, IMMOBILIZE, IMMOBILIZE_WEAKEN, DAMAGE, FIRE }

    private final Effect effect;
    private final String infoKey;

    public TortureBlock(Properties properties, Effect effect, String infoKey) {
        super(properties);
        this.effect = effect;
        this.infoKey = infoKey;
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide || !(entity instanceof LivingEntity living)) return;
        switch (effect) {
            case IMMOBILIZE -> immobilize(living);
            case IMMOBILIZE_WEAKEN -> {
                immobilize(living);
                living.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0, false, false, true));
            }
            case DAMAGE -> {
                living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 3, false, false, true));
                if (living.tickCount % 20 == 0) {
                    living.hurt(level.damageSources().cactus(), 1.0F);
                }
            }
            case FIRE -> {
                if (living.tickCount % 20 == 0) {
                    living.setSecondsOnFire(3);
                }
            }
            default -> { }
        }
    }

    private static void immobilize(LivingEntity living) {
        living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 6, false, false, true));
        living.addEffect(new MobEffectInstance(MobEffects.JUMP, 20, 128, false, false, false));
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide && hand == InteractionHand.MAIN_HAND && player.getMainHandItem().isEmpty()) {
            player.displayClientMessage(Component.translatable(infoKey).withStyle(ChatFormatting.GRAY), false);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
