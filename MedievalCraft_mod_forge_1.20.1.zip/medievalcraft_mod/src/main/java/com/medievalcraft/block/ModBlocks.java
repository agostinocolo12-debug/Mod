package com.medievalcraft.block;

import com.medievalcraft.MedievalCraft;
import com.medievalcraft.item.ModItems;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

// FILE GENERATO da tools/generate.py - modifica la tabella nello script, non questo file.
public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, MedievalCraft.MODID);

    private static void dev(String name, TortureBlock.Effect effect, boolean metal) {
        BlockBehaviour.Properties props = BlockBehaviour.Properties.of()
                .strength(metal ? 5.0F : 2.5F, 6.0F)
                .sound(metal ? SoundType.METAL : SoundType.WOOD);
        if (effect != TortureBlock.Effect.NONE) {
            props = props.noCollission();
        }
        final BlockBehaviour.Properties finalProps = props;
        RegistryObject<Block> block = BLOCKS.register(name,
                () -> new TortureBlock(finalProps, effect, "info.medievalcraft." + name));
        ModItems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
    }

    static {
        dev("ruota_del_supplizio", TortureBlock.Effect.IMMOBILIZE_WEAKEN, false);
        dev("cavalletto", TortureBlock.Effect.IMMOBILIZE_WEAKEN, false);
        dev("vergine_di_ferro", TortureBlock.Effect.DAMAGE, true);
        dev("gogna", TortureBlock.Effect.IMMOBILIZE, false);
        dev("ceppi", TortureBlock.Effect.IMMOBILIZE, false);
        dev("ghigliottina", TortureBlock.Effect.NONE, false);
        dev("forca", TortureBlock.Effect.NONE, false);
        dev("gabbia_sospesa", TortureBlock.Effect.IMMOBILIZE, true);
        dev("sedia_dei_chiodi", TortureBlock.Effect.DAMAGE, true);
        dev("sgabello_dell_annegamento", TortureBlock.Effect.NONE, false);
        dev("culla_di_giuda", TortureBlock.Effect.DAMAGE, false);
        dev("toro_di_falaride", TortureBlock.Effect.FIRE, true);
        dev("strappado", TortureBlock.Effect.IMMOBILIZE_WEAKEN, false);
        dev("cavallo_di_legno", TortureBlock.Effect.IMMOBILIZE, false);
        dev("oubliette", TortureBlock.Effect.IMMOBILIZE, false);
        dev("ceppo_del_boia", TortureBlock.Effect.NONE, false);
        dev("braciere_ferri_roventi", TortureBlock.Effect.FIRE, true);
        dev("tavolo_degli_interrogatori", TortureBlock.Effect.IMMOBILIZE, false);
        dev("letto_di_chiodi", TortureBlock.Effect.DAMAGE, true);
    }
}
