package com.medievalcraft;

import com.medievalcraft.block.ModBlocks;
import com.medievalcraft.item.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(MedievalCraft.MODID)
public class MedievalCraft {
    public static final String MODID = "medievalcraft";

    public MedievalCraft() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        // ModBlocks prima di ModItems: i blocchi registrano anche i propri BlockItem.
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModTabs.TABS.register(bus);
    }
}
