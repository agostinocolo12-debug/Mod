# MedievalCraft (Forge 1.20.1)

Mod a tema medievale: abiti, cibi, armi, strumenti e macchine di tortura storiche.

## Come compilarla
1. Scarica l'MDK di Forge 1.20.1 (47.3.0) da https://files.minecraftforge.net e copia in questa cartella `gradlew`, `gradlew.bat` e la cartella `gradle/` (il wrapper non e' incluso).
2. Serve Java 17.
3. Esegui `./gradlew build` (Windows: `gradlew build`).
4. Il file `.jar` finale si trova in `build/libs/` : mettilo nella cartella `mods` di Minecraft con Forge 1.20.1.

Per provarla subito: `./gradlew runClient`.

## Contenuto
- 13 cibi (pane nero, stufato di cinghiale, torta di carne...) + 3 bevande (idromele, birra, ipocrasso)
- 18 capi: set Contadino, Nobile, Monaco, Boia + Maschera della vergogna e Stivale spagnolo
- 7 armi (frusta, gatto a nove code, mazzafrusto, mazza ferrata, stella del mattino, spada e ascia del boia)
- 6 strumenti da usare con tasto destro su una creatura (tenaglie roventi, pollici, pera dell'angoscia, ferro da marchio, manette, corda del boia)
- 19 macchine (ruota, cavalletto, vergine di ferro, gogna, ceppi, ghigliottina, forca, gabbia sospesa, ecc.): tasto destro a mano vuota = nota storica; quelle "trappola" trattengono/danneggiano chi ci entra

Le macchine si craftano al tagliapietre: assi di quercia (legno) o blocco di ferro (metallo).

## Modificare il contenuto
Le tabelle sono in `tools/generate.py`. Dopo ogni modifica: `python3 tools/generate.py`.
Le texture sono segnaposto generate da codice: sostituiscile con le tue in
`src/main/resources/assets/medievalcraft/textures/`.
